
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

const formatDictionaryContext = (dictionary?: string[]) => {
  if (!dictionary || dictionary.length === 0) return "";
  return `\nUser's Personal Dictionary (Prioritize these exact spellings/words): [${dictionary.join(', ')}]\n`;
};

export const transliterateToBangla = async (text: string, dictionary?: string[]): Promise<string> => {
  try {
    const ai = getAIClient();
    const dictContext = formatDictionaryContext(dictionary);
    const prompt = `Transliterate the following Romanized text (phonetic Bangla) into proper Bangla script (Bengali).
    
    Rules:
    1. Only return the Bangla text.
    2. Do not add any explanations or notes.
    3. Maintain punctuation and formatting.
    4. Example: "ami" -> "আমি", "kemon acho?" -> "কেমন আছো?"
    ${dictContext}
    
    Input Text:
    "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text?.trim() || text;
  } catch (error) {
    console.error("Gemini Transliteration Error:", error);
    throw error;
  }
};

export const translateText = async (text: string, targetLang: string, dictionary?: string[]): Promise<string> => {
  try {
    const ai = getAIClient();
    const dictContext = formatDictionaryContext(dictionary);
    const prompt = `Translate the following text to ${targetLang}.
    
    Rules:
    1. Only return the translated text.
    2. Maintain the tone and context.
    ${dictContext}
    
    Input Text:
    "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text?.trim() || text;
  } catch (error) {
    console.error("Gemini Translation Error:", error);
    throw error;
  }
};

export const fixGrammar = async (text: string, dictionary?: string[]): Promise<string> => {
  try {
    const ai = getAIClient();
    const dictContext = formatDictionaryContext(dictionary);
    const prompt = `Fix the grammar and spelling of the following text (detect language automatically, Bangla or English).
    
    Rules:
    1. Only return the corrected text.
    2. Improve flow if necessary but keep original meaning.
    ${dictContext}
    
    Input Text:
    "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text?.trim() || text;
  } catch (error) {
    console.error("Gemini Grammar Fix Error:", error);
    throw error;
  }
};

export const generateSmartCompletion = async (text: string, language: string, dictionary?: string[]): Promise<string> => {
  try {
    const ai = getAIClient();
    const dictContext = formatDictionaryContext(dictionary);
    const prompt = `You are a smart keyboard assistant. The user is typing in ${language}.
    
    Task:
    - If the input is a question, provide a concise answer.
    - If the input is incomplete, complete the sentence or thought naturally.
    - If the input is a topic, write a short paragraph about it.
    
    Rules:
    1. Return ONLY the new text to be appended or the replacement text.
    2. Keep it natural and consistent with the input tone.
    3. Language: ${language}
    ${dictContext}
    
    User Input:
    "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text?.trim() || "";
  } catch (error) {
    console.error("Gemini Smart Completion Error:", error);
    throw error;
  }
};
