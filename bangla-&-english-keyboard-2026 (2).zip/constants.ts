
import { KeyData, ThemeType, ThemeDefinition } from './types';

export const ENGLISH_LAYOUT: KeyData[][] = [
  [
    { char: 'q', shift: 'Q' }, { char: 'w', shift: 'W' }, { char: 'e', shift: 'E' }, { char: 'r', shift: 'R' }, { char: 't', shift: 'T' },
    { char: 'y', shift: 'Y' }, { char: 'u', shift: 'U' }, { char: 'i', shift: 'I' }, { char: 'o', shift: 'O' }, { char: 'p', shift: 'P' }
  ],
  [
    { char: 'a', shift: 'A' }, { char: 's', shift: 'S' }, { char: 'd', shift: 'D' }, { char: 'f', shift: 'F' }, { char: 'g', shift: 'G' },
    { char: 'h', shift: 'H' }, { char: 'j', shift: 'J' }, { char: 'k', shift: 'K' }, { char: 'l', shift: 'L' }
  ],
  [
    { char: 'z', shift: 'Z' }, { char: 'x', shift: 'X' }, { char: 'c', shift: 'C' }, { char: 'v', shift: 'V' }, { char: 'b', shift: 'B' },
    { char: 'n', shift: 'N' }, { char: 'm', shift: 'M' }
  ]
];

export const NUMBER_PAD_LAYOUT: KeyData[][] = [
  [
    { char: '1' }, { char: '2' }, { char: '3' }, { char: '+' }
  ],
  [
    { char: '4' }, { char: '5' }, { char: '6' }, { char: '-' }
  ],
  [
    { char: '7' }, { char: '8' }, { char: '9' }, { char: '*' }
  ],
  [
    { char: '.' }, { char: '0' }, { char: ',' }, { char: '/' }
  ],
  [
    { char: '(' }, { char: ')' }, { char: '%' }, { char: '=' }
  ]
];

export const EMOJI_LAYOUT: KeyData[][] = [
  [
    { char: '😀' }, { char: '😂' }, { char: '🤣' }, { char: '😍' }, { char: '🥰' }, { char: '😎' }, { char: '🤓' }, { char: '😭' }
  ],
  [
    { char: '😤' }, { char: '😡' }, { char: '🤯' }, { char: '😳' }, { char: '🥵' }, { char: '🥶' }, { char: '😱' }, { char: '🤔' }
  ],
  [
    { char: '👍' }, { char: '👎' }, { char: '👏' }, { char: '🤝' }, { char: '✌️' }, { char: '🤞' }, { char: '🤟' }, { char: '🙏' }
  ],
  [
    { char: '❤️' }, { char: '🧡' }, { char: '💛' }, { char: '💚' }, { char: '💙' }, { char: '💜' }, { char: '🖤' }, { char: '💔' }
  ],
  [
    { char: '🔥' }, { char: '✨' }, { char: '🎉' }, { char: '💯' }, { char: '👀' }, { char: '🧠' }, { char: '🤖' }, { char: '👻' }
  ]
];

export const BANGLA_VOWELS: KeyData[] = [
  { char: 'অ' }, { char: 'আ' }, { char: 'ই' }, { char: 'ঈ' }, { char: 'উ' },
  { char: 'ঊ' }, { char: 'ঋ' }, { char: 'এ' }, { char: 'ঐ' }, { char: 'ও' }, { char: 'ঔ' }
];

export const BANGLA_MARKS: KeyData[] = [
  { char: 'া', display: 'া (aa)' }, { char: 'ি', display: 'ি (i)' }, { char: 'ী', display: 'ী (I)' },
  { char: 'ু', display: 'ু (u)' }, { char: 'ূ', display: 'ূ (U)' }, { char: 'ৃ', display: 'ৃ (ri)' },
  { char: 'ে', display: 'ে (e)' }, { char: 'ৈ', display: 'ৈ (oi)' }, { char: 'ো', display: 'ো (o)' },
  { char: 'ৌ', display: 'ৌ (ou)' }, { char: 'ং', display: 'ং' }, { char: 'ঃ', display: 'ঃ' }, { char: 'ঁ', display: 'ঁ' },
  { char: '্', display: '্ (Has)' }
];

export const BANGLA_CONSONANTS: KeyData[][] = [
  [
    { char: 'ক' }, { char: 'খ' }, { char: 'গ' }, { char: 'ঘ' }, { char: 'ঙ' }
  ],
  [
    { char: 'চ' }, { char: 'ছ' }, { char: 'জ' }, { char: 'ঝ' }, { char: 'ঞ' }
  ],
  [
    { char: 'ট' }, { char: 'ঠ' }, { char: 'ড' }, { char: 'ঢ' }, { char: 'ণ' }
  ],
  [
    { char: 'ত' }, { char: 'থ' }, { char: 'দ' }, { char: 'ধ' }, { char: 'ন' }
  ],
  [
    { char: 'প' }, { char: 'ফ' }, { char: 'ব' }, { char: 'ভ' }, { char: 'ম' }
  ],
  [
    { char: 'য' }, { char: 'র' }, { char: 'ল' }, { char: 'শ' }, { char: 'ষ' },
    { char: 'স' }, { char: 'হ' }, { char: 'ড়' }, { char: 'ঢ়' }, { char: 'য়' }
  ],
  [
    { char: 'ৎ' }, { char: '০' }, { char: '১' }, { char: '২' }, { char: '৩' },
    { char: '৪' }, { char: '৫' }, { char: '৬' }, { char: '৭' }, { char: '৮' }, { char: '৯' }
  ]
];

export const DEFAULT_CUSTOM_THEME: ThemeDefinition = {
  '--bg-app': '#202020',
  '--bg-panel': 'rgba(40, 40, 40, 0.9)',
  '--bg-key': '#303030',
  '--bg-key-hover': '#404040',
  '--border-key': '#505050',
  '--text-primary': '#ffffff',
  '--text-secondary': '#aaaaaa',
  '--accent-color': '#ffcc00',
  '--text-accent': '#000000',
};

export const THEMES: Record<Exclude<ThemeType, ThemeType.CUSTOM>, ThemeDefinition> = {
  [ThemeType.NEON]: {
    '--bg-app': '#050505',
    '--bg-panel': 'rgba(17, 25, 40, 0.75)',
    '--bg-key': '#1f2937',
    '--bg-key-hover': '#374151',
    '--border-key': '#374151',
    '--text-primary': '#ffffff',
    '--text-secondary': '#9ca3af',
    '--accent-color': '#00f3ff',
    '--text-accent': '#000000',
  },
  [ThemeType.LIGHT]: {
    '--bg-app': '#f3f4f6',
    '--bg-panel': 'rgba(255, 255, 255, 0.85)',
    '--bg-key': '#ffffff',
    '--bg-key-hover': '#e5e7eb',
    '--border-key': '#d1d5db',
    '--text-primary': '#111827',
    '--text-secondary': '#4b5563',
    '--accent-color': '#3b82f6',
    '--text-accent': '#ffffff',
  },
  [ThemeType.DARK]: {
    '--bg-app': '#0f172a',
    '--bg-panel': 'rgba(30, 41, 59, 0.8)',
    '--bg-key': '#334155',
    '--bg-key-hover': '#475569',
    '--border-key': '#475569',
    '--text-primary': '#f1f5f9',
    '--text-secondary': '#94a3b8',
    '--accent-color': '#60a5fa',
    '--text-accent': '#0f172a',
  },
  [ThemeType.FOREST]: {
    '--bg-app': '#052e16',
    '--bg-panel': 'rgba(20, 83, 45, 0.6)',
    '--bg-key': '#14532d',
    '--bg-key-hover': '#166534',
    '--border-key': '#166534',
    '--text-primary': '#ecfccb',
    '--text-secondary': '#a3e635',
    '--accent-color': '#84cc16',
    '--text-accent': '#064e3b',
  },
};

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'bn', name: 'Bangla', flag: '🇧🇩' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'tr', name: 'Turkish', flag: '🇹🇷' },
  { code: 'ur', name: 'Urdu', flag: '🇵🇰' },
  { code: 'vi', name: 'Vietnamese', flag: '🇻🇳' },
  { code: 'th', name: 'Thai', flag: '🇹🇭' },
  { code: 'id', name: 'Indonesian', flag: '🇮🇩' },
];
