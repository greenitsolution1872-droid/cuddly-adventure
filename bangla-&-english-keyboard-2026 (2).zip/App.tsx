

import React, { useState, useRef, useEffect } from 'react';
import { LayoutMode, AIStatus, OSType, ThemeType, ThemeDefinition, BeforeInstallPromptEvent } from './types';
import { VirtualKeyboard } from './components/VirtualKeyboard';
import { THEMES, SUPPORTED_LANGUAGES, DEFAULT_CUSTOM_THEME } from './constants';
import { ThemeCustomizer } from './components/ThemeCustomizer';
import { PersonalDictionary } from './components/PersonalDictionary';
import { PolicyModal } from './components/PolicyModal';
import { transliterateToBangla, translateText, fixGrammar, generateSmartCompletion } from './services/geminiService';
import { 
  Keyboard, 
  Languages, 
  CheckCheck, 
  Copy, 
  Trash2, 
  Loader2,
  Sparkles,
  Smartphone,
  Monitor,
  Apple,
  Globe,
  Palette,
  Edit3,
  Volume2,
  VolumeX,
  ChevronDown,
  Download,
  Share,
  X,
  Menu,
  ShieldCheck,
  Zap,
  Laptop,
  Book,
  Mic,
  Camera,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  Paperclip,
  XCircle,
  Save
} from 'lucide-react';

const App: React.FC = () => {
  const [text, setText] = useState('');
  const [mode, setMode] = useState<LayoutMode>(LayoutMode.ENGLISH);
  const [aiStatus, setAiStatus] = useState<AIStatus>(AIStatus.IDLE);
  const [capsLock, setCapsLock] = useState(false);
  const [os, setOs] = useState<OSType>('Unknown');
  const [currentTheme, setCurrentTheme] = useState<ThemeType>(ThemeType.NEON);
  const [targetLang, setTargetLang] = useState('English');
  const [customTheme, setCustomTheme] = useState<ThemeDefinition>(() => {
    const saved = localStorage.getItem('customTheme');
    return saved ? JSON.parse(saved) : DEFAULT_CUSTOM_THEME;
  });
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(() => {
    const saved = localStorage.getItem('soundEnabled');
    return saved !== null ? JSON.parse(saved) : true;
  });
  const [transliterationEnabled, setTransliterationEnabled] = useState(false);
  
  // Voice Command State
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  // Personal Dictionary State
  const [personalDictionary, setPersonalDictionary] = useState<string[]>(() => {
    const saved = localStorage.getItem('personalDictionary');
    return saved ? JSON.parse(saved) : [];
  });
  const [showDictionary, setShowDictionary] = useState(false);
  
  // Policies State
  const [policyOpen, setPolicyOpen] = useState<'privacy' | 'terms' | null>(null);
  
  // PWA Install State
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showInstallModal, setShowInstallModal] = useState(false);

  // Media & Attachments State
  const [attachments, setAttachments] = useState<File[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Hidden File Inputs Refs
  const fileInputCamera = useRef<HTMLInputElement>(null);
  const fileInputImage = useRef<HTMLInputElement>(null);
  const fileInputVideo = useRef<HTMLInputElement>(null);
  const fileInputAudio = useRef<HTMLInputElement>(null);
  const fileInputDoc = useRef<HTMLInputElement>(null);

  // Apply Theme
  useEffect(() => {
    let themeVars: ThemeDefinition;
    if (currentTheme === ThemeType.CUSTOM) {
      themeVars = customTheme;
    } else {
      themeVars = THEMES[currentTheme];
    }
    
    Object.entries(themeVars).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value as string);
    });
  }, [currentTheme, customTheme]);

  // Save Custom Theme
  useEffect(() => {
    localStorage.setItem('customTheme', JSON.stringify(customTheme));
  }, [customTheme]);

  // Save Sound Preference
  useEffect(() => {
    localStorage.setItem('soundEnabled', JSON.stringify(soundEnabled));
  }, [soundEnabled]);

  // Save Personal Dictionary
  useEffect(() => {
    localStorage.setItem('personalDictionary', JSON.stringify(personalDictionary));
  }, [personalDictionary]);

  // Detect OS
  useEffect(() => {
    const userAgent = window.navigator.userAgent;
    if (/android/i.test(userAgent)) {
      setOs('Android');
    } else if (/iPad|iPhone|iPod/.test(userAgent)) {
      setOs('iOS');
    } else if (/windows/i.test(userAgent)) {
      setOs('Windows');
    } else if (/macintosh|mac os x/i.test(userAgent)) {
      setOs('MacOS');
    } else if (/linux/i.test(userAgent)) {
      setOs('Linux');
    }
  }, []);

  // PWA Install Prompt Listener
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  // Focus textarea on load, but be careful on mobile to not auto-open native keyboard
  useEffect(() => {
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS' || os === 'Linux')) {
      textareaRef.current.focus();
    }
  }, [os]);

  const handleKeyPress = (char: string) => {
    setText(prev => prev + char);
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }
  };

  const handleBackspace = () => {
    setText(prev => prev.slice(0, -1));
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }
  };

  const handleSpace = async () => {
    // 1. Capture current text before space is added for processing
    const textBeforeSpace = text;
    
    // 2. Add space immediately to UI
    setText(prev => prev + ' ');
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }

    // 3. Live Transliteration Logic
    if (transliterationEnabled && mode === LayoutMode.ENGLISH) {
       // Find the last word typed
       const words = textBeforeSpace.trim().split(/\s+/);
       const lastWord = words[words.length - 1];
       
       // Only transliterate if it looks like an English word (alphabetic) and isn't empty
       if (lastWord && /^[a-zA-Z]+$/.test(lastWord)) {
          setAiStatus(AIStatus.LOADING);
          try {
             // We pass the personal dictionary so names/custom words are respected
             const banglaWord = await transliterateToBangla(lastWord, personalDictionary);
             
             // Update the text state: replace the last occurrence of the word with the transliterated one
             setText(prev => {
                // We reconstruct the text replacement carefully
                // Safety check: ensure the text still ends with "lastWord " (user hasn't typed massively ahead)
                if (prev.endsWith(lastWord + ' ')) {
                   // Remove "lastWord " (len + 1 for space) and append "banglaWord "
                   return prev.slice(0, -(lastWord.length + 1)) + banglaWord + ' ';
                }
                return prev;
             });
             setAiStatus(AIStatus.SUCCESS);
          } catch(e) {
             console.error("Auto-transliterate failed", e);
             setAiStatus(AIStatus.ERROR);
          } finally {
             setTimeout(() => setAiStatus(AIStatus.IDLE), 1000);
          }
       }
    }
  };

  // Voice Command / Speech to Text Logic
  const handleVoiceCommand = (transcript: string) => {
      const lower = transcript.toLowerCase().trim();
      
      // Basic commands
      if (lower === 'clear text' || lower === 'clear all' || lower === 'shob muche felun') {
          if(window.confirm('Clear all text?')) setText('');
      } else if (lower === 'backspace' || lower === 'delete' || lower === 'katun') {
          setText(prev => prev.slice(0, -1));
      } else if (lower === 'new line' || lower === 'enter' || lower === 'notun line') {
          setText(prev => prev + '\n');
      } else {
          // Default: Append text
          setText(prev => prev + transcript + ' ');
      }
      
      // Keep focus
      if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
        textareaRef.current.focus();
      }
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input is not supported in this browser. Please use Chrome, Edge or Safari.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false; // Simple toggle interaction
    recognition.interimResults = false;
    
    // Set language based on mode
    let lang = 'en-US';
    if (mode === LayoutMode.BANGLA_CONSONANTS || 
        mode === LayoutMode.BANGLA_VOWELS || 
        mode === LayoutMode.BANGLA_MARKS) {
      lang = 'bn-BD'; // Bangla (Bangladesh)
    }
    recognition.lang = lang;

    recognition.onstart = () => setIsListening(true);
    
    recognition.onend = () => {
        setIsListening(false);
    };
    
    recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsListening(false);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      handleVoiceCommand(transcript);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  // Media Handlers
  const triggerFileInput = (ref: React.RefObject<HTMLInputElement>) => {
    ref.current?.click();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
    // Reset value to allow selecting same file again
    if (e.target) e.target.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleDownloadContent = () => {
    if (!text && attachments.length === 0) {
        alert("Type some text first!");
        return;
    }
    
    // Create text file
    const element = document.createElement("a");
    const file = new Blob([text], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `BanglaBoard_Note_${new Date().toISOString().slice(0,10)}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(text);
  };

  const clearText = () => {
    if (window.confirm('Clear all text and attachments?')) {
      setText('');
      setAttachments([]);
    }
  };

  const updateCustomTheme = (key: keyof ThemeDefinition, value: string) => {
    setCustomTheme(prev => ({ ...prev, [key]: value }));
  };

  const resetCustomTheme = () => {
    if (window.confirm('Reset custom theme to defaults?')) {
        setCustomTheme(DEFAULT_CUSTOM_THEME);
    }
  };

  const addWordToDictionary = (word: string) => {
      if (!personalDictionary.includes(word)) {
          setPersonalDictionary(prev => [...prev, word]);
      }
  };

  const removeWordFromDictionary = (word: string) => {
      setPersonalDictionary(prev => prev.filter(w => w !== word));
  };

  const clearDictionary = () => {
      setPersonalDictionary([]);
  };

  // Install Action
  const handleInstallClick = async () => {
    if (installPrompt) {
      installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      if (outcome === 'accepted') {
        setInstallPrompt(null);
        setShowInstallModal(false);
      }
    } else {
      setShowInstallModal(true);
    }
  };

  // AI Actions
  const handleTransliterate = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await transliterateToBangla(text, personalDictionary);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleTranslate = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await translateText(text, targetLang, personalDictionary);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleFixGrammar = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await fixGrammar(text, personalDictionary);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleAiMagic = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    
    // Determine context language based on current keyboard mode
    let contextLang = targetLang;
    if (mode === LayoutMode.BANGLA_CONSONANTS || 
        mode === LayoutMode.BANGLA_VOWELS || 
        mode === LayoutMode.BANGLA_MARKS) {
      contextLang = "Bangla";
    }

    try {
      const result = await generateSmartCompletion(text, contextLang, personalDictionary);
      if (result) {
          setText(prev => prev + " " + result);
      }
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const getOSIcon = () => {
    switch(os) {
      case 'Android': return <Smartphone size={16} className="text-green-500" />;
      case 'iOS': return <Apple size={16} className="text-gray-200" />;
      case 'MacOS': return <Apple size={16} className="text-gray-200" />;
      case 'Windows': return <Monitor size={16} className="text-blue-400" />;
      default: return <Monitor size={16} className="text-t-textMuted" />;
    }
  };
  
  const getInstallText = () => {
    switch(os) {
      case 'Android': return "Get for Android";
      case 'iOS': return "Get for iOS";
      case 'Windows': return "Get for Windows";
      case 'MacOS': return "Get for Mac";
      default: return "Download App";
    }
  };

  const selectedLanguage = SUPPORTED_LANGUAGES.find(l => l.name === targetLang) || SUPPORTED_LANGUAGES[0];

  const layoutOptions = [
    { value: LayoutMode.ENGLISH, label: 'English (ABC)' },
    { value: LayoutMode.NUMBER_PAD, label: 'Numbers (123)' },
    { value: LayoutMode.EMOJI, label: 'Emoji (😊)' },
    { value: LayoutMode.BANGLA_CONSONANTS, label: 'Bangla: Consonants' },
    { value: LayoutMode.BANGLA_VOWELS, label: 'Bangla: Vowels' },
    { value: LayoutMode.BANGLA_MARKS, label: 'Bangla: Marks' },
  ];

  return (
    <div className="min-h-screen bg-t-bg text-t-text flex flex-col font-sans selection:bg-t-accent selection:text-t-accentText pb-10 transition-colors duration-300">
      {/* Background Ambience */}
      {(currentTheme === ThemeType.NEON || currentTheme === ThemeType.DARK || currentTheme === ThemeType.CUSTOM) && (
        <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-t-accent opacity-10 blur-[120px] rounded-full animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-t-accent opacity-10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        </div>
      )}

      {/* Hidden File Inputs */}
      <input type="file" ref={fileInputCamera} accept="image/*" capture="environment" className="hidden" onChange={handleFileSelect} />
      <input type="file" ref={fileInputImage} accept="image/*" className="hidden" onChange={handleFileSelect} />
      <input type="file" ref={fileInputVideo} accept="video/*" className="hidden" onChange={handleFileSelect} />
      <input type="file" ref={fileInputAudio} accept="audio/*" className="hidden" onChange={handleFileSelect} />
      <input type="file" ref={fileInputDoc} accept=".pdf,.doc,.docx,.txt" className="hidden" onChange={handleFileSelect} />

      {/* Header */}
      <header className="w-full p-3 md:p-6 flex flex-col md:flex-row items-center justify-between border-b border-t-border glass-panel sticky top-0 z-50 transition-colors duration-300 gap-3">
        <div className="flex items-center justify-between w-full md:w-auto">
          <div className="flex items-center gap-3">
            <div className="bg-t-accent p-2 rounded-lg">
              <Keyboard className="text-t-accentText" size={24} />
            </div>
            <div>
              <h1 className="text-lg md:text-2xl font-bold tracking-tight text-t-text leading-tight">
                BanglaBoard <span className="text-t-accent">2026</span>
              </h1>
              <div className="flex items-center gap-2">
                <span className="text-[10px] md:text-xs text-t-textMuted font-medium hidden sm:inline-block">AI-Powered Input</span>
                {os !== 'Unknown' && (
                  <div className="flex items-center gap-1 bg-white/5 px-2 py-0.5 rounded-full border border-t-border">
                    {getOSIcon()}
                    <span className="text-[10px] text-t-textMuted uppercase font-semibold">Optimized for {os}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className={`md:hidden px-3 py-1 rounded-full text-[10px] font-bold border ${aiStatus === AIStatus.LOADING ? 'border-neon-pink text-neon-pink animate-pulse' : 'border-t-border text-t-textMuted'}`}>
             {aiStatus === AIStatus.LOADING ? 'BUSY' : 'READY'}
          </div>
        </div>
        
        <div className="flex items-center gap-2 md:gap-3 w-full md:w-auto justify-end">
           <div className="relative flex items-center bg-t-key border border-t-border rounded-lg px-2 py-1.5 gap-2 group hover:border-t-accent transition-colors">
              <Keyboard size={16} className="text-t-textMuted group-hover:text-t-accent transition-colors flex-shrink-0"/>
              <select 
                value={mode} 
                onChange={(e) => setMode(e.target.value as LayoutMode)}
                className="bg-transparent outline-none text-xs md:text-sm font-medium text-t-text appearance-none cursor-pointer w-[110px] sm:w-[130px] md:w-auto"
              >
                {layoutOptions.map(opt => (
                  <option key={opt.value} value={opt.value} className="bg-t-bg text-t-text">
                    {opt.label}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="text-t-textMuted pointer-events-none absolute right-2 bg-t-key pl-1" />
           </div>

           <div className="h-6 w-px bg-t-border mx-1"></div>

           <button 
             onClick={() => setSoundEnabled(!soundEnabled)}
             className="p-1.5 md:p-2 rounded-full border border-t-border bg-t-key text-t-textMuted hover:text-t-accent hover:bg-t-keyHover transition-all flex-shrink-0"
             title={soundEnabled ? "Mute Sound" : "Enable Sound"}
           >
             {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
           </button>
           
           <button 
             onClick={() => setShowDictionary(true)}
             className="p-1.5 md:p-2 rounded-full border border-t-border bg-t-key text-t-textMuted hover:text-t-accent hover:bg-t-keyHover transition-all flex-shrink-0"
             title="Personal Dictionary"
           >
             <Book size={18} />
           </button>

           <div className="flex items-center gap-1 bg-t-key rounded-full p-1 border border-t-border flex-shrink-0">
             {[ThemeType.NEON, ThemeType.LIGHT, ThemeType.DARK, ThemeType.FOREST].map(t => (
               <button
                 key={t}
                 onClick={() => setCurrentTheme(t)}
                 className={`w-5 h-5 md:w-6 md:h-6 rounded-full border border-t-border transition-transform ${currentTheme === t ? 'scale-110 ring-2 ring-t-accent' : 'hover:scale-105 opacity-60 hover:opacity-100'}`}
                 style={{ backgroundColor: THEMES[t]['--bg-app'] }}
                 title={t}
               />
             ))}
             
             <div className="relative flex items-center">
                <button
                    onClick={() => {
                        setCurrentTheme(ThemeType.CUSTOM);
                        if (currentTheme === ThemeType.CUSTOM) setShowCustomizer(true);
                    }}
                    className={`w-5 h-5 md:w-6 md:h-6 rounded-full border border-t-border flex items-center justify-center transition-all overflow-hidden ${currentTheme === ThemeType.CUSTOM ? 'scale-110 ring-2 ring-t-accent' : 'hover:scale-105 opacity-60 hover:opacity-100'}`}
                    style={{ background: 'conic-gradient(from 0deg, red, yellow, lime, aqua, blue, magenta, red)' }}
                    title="Custom Theme"
                >
                    {currentTheme === ThemeType.CUSTOM && (
                         <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[1px]">
                             <Palette size={10} className="text-white" />
                         </div>
                    )}
                </button>
             </div>
           </div>
           
           {currentTheme === ThemeType.CUSTOM && (
               <button 
                  onClick={() => setShowCustomizer(true)}
                  className="p-1.5 rounded-full bg-t-key border border-t-border hover:border-t-accent text-t-textMuted hover:text-t-accent transition-colors flex-shrink-0"
                  title="Edit Custom Theme"
               >
                   <Edit3 size={14} />
               </button>
           )}

           <button
              onClick={handleInstallClick}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-t-accent to-blue-500 text-t-accentText font-bold shadow-lg hover:brightness-110 transition-all active:scale-95 ml-2"
           >
              <Download size={16} />
              <span className="text-xs">{getInstallText()}</span>
           </button>

           <div className={`hidden md:block px-3 py-1 rounded-full text-[10px] md:text-xs font-bold border ${aiStatus === AIStatus.LOADING ? 'border-neon-pink text-neon-pink animate-pulse' : 'border-t-border text-t-textMuted'}`}>
             {aiStatus === AIStatus.LOADING ? 'PROCESSING' : 'ONLINE'}
           </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-6xl mx-auto p-2 md:p-8 flex flex-col gap-4 md:gap-6">
        
        {/* Editor Section */}
        <section className="relative group mt-2 md:mt-0">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-t-accent to-t-textMuted rounded-2xl opacity-20 group-hover:opacity-40 transition duration-500 blur-md"></div>
          <div className="relative glass-panel rounded-2xl p-3 md:p-6 h-auto min-h-[250px] md:min-h-[350px] flex flex-col">
            
            {/* Text Area */}
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={`Start typing... or use the media icons below to attach files.`}
              className="flex-1 bg-transparent border-none outline-none resize-none text-lg md:text-2xl font-bangla leading-relaxed placeholder-t-textMuted w-full text-t-text min-h-[150px]"
              spellCheck="false"
            />

            {/* Attachments Preview */}
            {attachments.length > 0 && (
              <div className="flex gap-2 overflow-x-auto pb-2 mb-2 custom-scrollbar">
                {attachments.map((file, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-t-key border border-t-border rounded-lg px-2 py-1 flex-shrink-0 max-w-[150px]">
                    <Paperclip size={12} className="text-t-accent" />
                    <span className="text-xs text-t-text truncate">{file.name}</span>
                    <button onClick={() => removeAttachment(idx)} className="text-t-textMuted hover:text-red-500">
                      <XCircle size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            
            {/* Editor Toolbar */}
            <div className="flex flex-col sm:flex-row justify-between items-center mt-2 border-t border-t-border pt-3 gap-3">
              
              {/* Left: Media Icons */}
              <div className="flex items-center gap-1 sm:gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 scrollbar-hide">
                 <button onClick={() => triggerFileInput(fileInputCamera)} className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors" title="Camera">
                    <Camera size={20} />
                 </button>
                 <button onClick={() => triggerFileInput(fileInputImage)} className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors" title="Gallery">
                    <ImageIcon size={20} />
                 </button>
                 <button onClick={() => triggerFileInput(fileInputVideo)} className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors" title="Video">
                    <Video size={20} />
                 </button>
                 <button onClick={() => triggerFileInput(fileInputAudio)} className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors" title="Audio">
                    <Music size={20} />
                 </button>
                 <button onClick={() => triggerFileInput(fileInputDoc)} className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors" title="Document">
                    <FileText size={20} />
                 </button>
                 <div className="h-5 w-px bg-t-border mx-1 hidden sm:block"></div>
                 {isListening && <span className="text-red-500 animate-pulse font-bold flex items-center gap-1 text-xs whitespace-nowrap"><Mic size={12} /> Recording...</span>}
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <div className="text-[10px] text-t-textMuted mr-2 hidden sm:block">
                    {text.length} chars
                </div>
                
                <button 
                  onClick={handleDownloadContent}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-t-key hover:bg-green-600/20 text-t-text hover:text-green-500 border border-t-border hover:border-green-500 rounded-lg transition-all text-xs font-bold"
                  title="Download Text File"
                >
                  <Save size={16} />
                  <span>Download</span>
                </button>

                <button 
                  onClick={copyToClipboard}
                  className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors"
                  title="Copy Text"
                >
                  <Copy size={18} />
                </button>
                <button 
                  onClick={clearText}
                  className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-red-500 transition-colors"
                  title="Clear All"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* AI Action Bar */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-2 md:gap-3">
          <button
            onClick={handleTransliterate}
            disabled={aiStatus === AIStatus.LOADING}
            className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-t-accent hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
            {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-t-accent" size={20} /> : <Sparkles className="text-t-accent group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Phonetic to Bangla</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">ami -{'>'} আমি</span>
          </button>

          <button
            onClick={handleFixGrammar}
            disabled={aiStatus === AIStatus.LOADING}
            className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-t-accent hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
             {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-t-accent" size={20} /> : <CheckCheck className="text-t-accent group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Fix Grammar</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">Auto-correct</span>
          </button>

          {/* Target Language Selector */}
          <div className="relative flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-blue-400 hover:bg-t-keyHover transition-all group text-t-text">
             <select 
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
             >
                {SUPPORTED_LANGUAGES.map(lang => (
                  <option key={lang.code} value={lang.name}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
             </select>
             <Globe className="text-blue-400 group-hover:scale-110 transition-transform" size={20} />
             <span className="text-xs md:text-sm font-medium truncate max-w-full px-2">{selectedLanguage.name}</span>
             <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">{selectedLanguage.flag} Target Lang</span>
          </div>

          <button
             onClick={handleTranslate}
             disabled={aiStatus === AIStatus.LOADING}
             className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-green-400 hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
             {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-green-400" size={20} /> : <Languages className="text-green-400 group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Translate</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">To {targetLang}</span>
          </button>
        </section>

        {/* Keyboard Section */}
        <section className="flex-1 pb-20">
          
          <div className="glass-panel p-1 md:p-6 rounded-2xl border-t border-t-border transition-colors duration-300">
            <VirtualKeyboard 
              mode={mode} 
              setMode={setMode}
              onKeyPress={handleKeyPress}
              onBackspace={handleBackspace}
              onSpace={handleSpace}
              capsLock={capsLock}
              toggleCapsLock={() => setCapsLock(!capsLock)}
              soundEnabled={soundEnabled}
              onAiMagic={handleAiMagic}
              transliterationEnabled={transliterationEnabled}
              toggleTransliteration={() => setTransliterationEnabled(prev => !prev)}
              isListening={isListening}
              toggleListening={toggleListening}
            />
          </div>
          
          <div className="text-center mt-6 text-t-textMuted text-xs flex flex-col items-center gap-4">
             <p>Use the <span className="inline-block px-1.5 py-0.5 rounded bg-gradient-to-r from-neon-blue to-neon-purple text-white text-[10px] font-bold">✨</span> key to auto-complete thoughts or answer questions in {targetLang}.</p>
             
             {/* Platform Support Footer */}
             <div className="flex flex-wrap justify-center gap-4 opacity-50 hover:opacity-100 transition-opacity">
                <div className="flex items-center gap-1.5">
                    <Smartphone size={14} className="text-green-500"/> <span className="text-[10px]">Android</span>
                </div>
                <div className="w-1 h-1 rounded-full bg-t-border self-center"></div>
                <div className="flex items-center gap-1.5">
                    <Apple size={14} className="text-t-text"/> <span className="text-[10px]">iPhone (iOS)</span>
                </div>
                <div className="w-1 h-1 rounded-full bg-t-border self-center"></div>
                <div className="flex items-center gap-1.5">
                    <Monitor size={14} className="text-blue-400"/> <span className="text-[10px]">Windows</span>
                </div>
             </div>

             {/* Developer Credit Footer */}
             <div className="mt-8 pt-6 border-t border-t-border/30 w-full flex flex-col items-center gap-1">
                <p className="text-[10px] font-medium text-t-textMuted uppercase tracking-wider">AI Apps Builder</p>
                <h3 className="text-sm md:text-base font-bold text-transparent bg-clip-text bg-gradient-to-r from-t-accent to-purple-500">
                  SHARIAR MAZUMDAR
                </h3>
                <p className="text-[10px] text-t-textMuted/60 mt-1 flex items-center gap-1.5">
                  <span>Developed by Google AI</span>
                  <span className="w-1 h-1 rounded-full bg-t-textMuted/40"></span>
                  <span>Copyright © 2026</span>
                  <span className="w-1 h-1 rounded-full bg-t-textMuted/40"></span>
                  <span>Bangladesh 🇧🇩</span>
                </p>
                
                {/* Policy Links */}
                <div className="flex gap-4 mt-3 text-[10px] text-t-textMuted/50">
                  <button onClick={() => setPolicyOpen('terms')} className="hover:text-t-text hover:underline transition-colors">Terms & Conditions</button>
                  <button onClick={() => setPolicyOpen('privacy')} className="hover:text-t-text hover:underline transition-colors">Privacy Policy</button>
                </div>
             </div>
          </div>
        </section>

        {/* Custom Theme Editor Modal */}
        {showCustomizer && (
            <ThemeCustomizer 
                theme={customTheme}
                onUpdate={updateCustomTheme}
                onReset={resetCustomTheme}
                onClose={() => setShowCustomizer(false)}
            />
        )}

        {/* Personal Dictionary Modal */}
        {showDictionary && (
            <PersonalDictionary 
                words={personalDictionary}
                onAddWord={addWordToDictionary}
                onRemoveWord={removeWordFromDictionary}
                onClearAll={clearDictionary}
                onClose={() => setShowDictionary(false)}
            />
        )}
        
        {/* Policy Modals */}
        {policyOpen && (
            <PolicyModal 
                type={policyOpen} 
                onClose={() => setPolicyOpen(null)} 
            />
        )}

        {/* Install / Download Modal */}
        {showInstallModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
             <div className="bg-t-panel border border-t-border rounded-xl p-6 w-full max-w-sm shadow-2xl relative flex flex-col">
                <button 
                  onClick={() => setShowInstallModal(false)} 
                  className="absolute top-4 right-4 text-t-textMuted hover:text-t-text transition-colors"
                >
                  <X size={20} />
                </button>

                <div className="flex flex-col items-center text-center gap-4">
                  <div className="relative">
                     <div className="w-16 h-16 bg-gradient-to-br from-t-accent to-purple-600 rounded-2xl shadow-lg flex items-center justify-center z-10 relative">
                       <Keyboard className="text-white w-8 h-8" />
                     </div>
                     <div className="absolute -inset-2 bg-t-accent opacity-20 blur-xl rounded-full"></div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold text-t-text">BanglaBoard 2026</h3>
                    <p className="text-t-textMuted text-sm">Next-Gen AI Keyboard</p>
                    <div className="flex items-center justify-center gap-1 mt-2 text-[10px] text-green-400 font-medium">
                      <ShieldCheck size={12} /> Safe & Secure Download
                    </div>
                  </div>

                  <div className="w-full h-px bg-t-border my-2"></div>
                  
                  {/* Dynamic Heading based on OS */}
                  <h4 className="text-sm font-semibold text-t-text">
                     {os === 'Android' ? 'Install on Android' : 
                      os === 'iOS' ? 'Install on iPhone/iPad' : 
                      os === 'Windows' ? 'Install on Windows' : 'Universal App Download'}
                  </h4>

                  <div className="flex flex-col gap-3 w-full">
                    {/* Android / Chrome */}
                    <button
                        onClick={() => {
                            if(installPrompt) installPrompt.prompt();
                            else if(os === 'Android') alert('Tap the browser menu (⋮) and select "Install App" or "Add to Home Screen".');
                            else alert('For Android: Open in Chrome > Menu > Install App');
                        }}
                        className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'Android' ? 'ring-2 ring-green-500/50 shadow-lg shadow-green-900/20' : 'opacity-80 hover:opacity-100'}`}
                        >
                        <Smartphone className="text-green-500" />
                        <div className="text-left">
                            <div className="text-[10px] uppercase text-t-textMuted font-bold">Get it on</div>
                            <div className="text-sm font-bold text-t-text">Google Play Store</div>
                        </div>
                        {os === 'Android' && <Zap size={16} className="ml-auto text-green-400 animate-pulse" />}
                    </button>

                    {/* iOS */}
                    <button
                        onClick={() => {
                            if(os === 'iOS') alert('Tap the Share button below, then scroll down and select "Add to Home Screen"');
                            else alert('On iPhone/iPad (Safari): Tap Share > Add to Home Screen');
                        }}
                        className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'iOS' ? 'ring-2 ring-gray-200/50 shadow-lg shadow-gray-700/20' : 'opacity-80 hover:opacity-100'}`}
                        >
                        <Apple className="text-white" />
                        <div className="text-left">
                            <div className="text-[10px] uppercase text-t-textMuted font-bold">Download on the</div>
                            <div className="text-sm font-bold text-t-text">App Store</div>
                        </div>
                        {os === 'iOS' && <Zap size={16} className="ml-auto text-white animate-pulse" />}
                    </button>

                    {/* Windows */}
                    <button
                        onClick={() => {
                            if(installPrompt && os === 'Windows') installPrompt.prompt();
                            else if(os === 'Windows') alert('Click the install icon (+) in your browser address bar to install.');
                            else alert('For Windows: Open in Edge/Chrome > Install icon in address bar');
                        }}
                        className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'Windows' ? 'ring-2 ring-blue-400/50 shadow-lg shadow-blue-900/20' : 'opacity-80 hover:opacity-100'}`}
                        >
                        <Monitor className="text-blue-400" />
                        <div className="text-left">
                            <div className="text-[10px] uppercase text-t-textMuted font-bold">Get it from</div>
                            <div className="text-sm font-bold text-t-text">Microsoft Store</div>
                        </div>
                        {os === 'Windows' && <Zap size={16} className="ml-auto text-blue-400 animate-pulse" />}
                    </button>
                  </div>
                  
                  {os === 'iOS' && (
                     <div className="mt-2 text-xs text-t-textMuted bg-t-key p-3 rounded-lg animate-pulse border border-t-border">
                        <div className="flex items-center justify-center gap-2 mb-1 font-bold text-t-text">
                           <Share size={14} /> Tap Share Button
                        </div>
                        Then select "Add to Home Screen"
                     </div>
                  )}
                  
                  <p className="text-[10px] text-t-textMuted mt-2">
                    Version 2.0.26 • Supported on Android, iOS, Windows
                  </p>
                </div>
             </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
