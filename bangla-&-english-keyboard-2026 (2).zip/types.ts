

export enum LayoutMode {
  ENGLISH = 'ENGLISH',
  BANGLA_VOWELS = 'BANGLA_VOWELS',
  BANGLA_CONSONANTS = 'BANGLA_CONSONANTS',
  BANGLA_MARKS = 'BANGLA_MARKS',
  NUMBER_PAD = 'NUMBER_PAD',
  EMOJI = 'EMOJI'
}

export interface KeyData {
  char: string;
  display?: string;
  shift?: string;
  code?: string;
}

export enum AIStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface KeyboardState {
  text: string;
  mode: LayoutMode;
  aiStatus: AIStatus;
  capsLock: boolean;
}

export type OSType = 'Android' | 'iOS' | 'Windows' | 'MacOS' | 'Linux' | 'Unknown';

export enum ThemeType {
  NEON = 'NEON',
  LIGHT = 'LIGHT',
  DARK = 'DARK',
  FOREST = 'FOREST',
  CUSTOM = 'CUSTOM'
}

export interface ThemeDefinition {
  '--bg-app': string;
  '--bg-panel': string;
  '--bg-key': string;
  '--bg-key-hover': string;
  '--border-key': string;
  '--text-primary': string;
  '--text-secondary': string;
  '--accent-color': string;
  '--text-accent': string;
}

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

declare global {
  interface Window {
    deferredPrompt?: BeforeInstallPromptEvent;
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}