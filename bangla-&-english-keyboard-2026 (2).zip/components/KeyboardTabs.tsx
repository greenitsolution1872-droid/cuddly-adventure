
import React from 'react';
import { LayoutMode } from '../types';

interface KeyboardTabsProps {
  currentMode: LayoutMode;
  setMode: (mode: LayoutMode) => void;
}

export const KeyboardTabs: React.FC<KeyboardTabsProps> = ({ currentMode, setMode }) => {
  const tabs = [
    { id: LayoutMode.ENGLISH, label: 'English (ABC)' },
    { id: LayoutMode.NUMBER_PAD, label: 'Numbers (123)' },
    { id: LayoutMode.EMOJI, label: 'Emoji (😊)' },
    { id: LayoutMode.BANGLA_CONSONANTS, label: 'ব্যঞ্জনবর্ণ (Consonants)' },
    { id: LayoutMode.BANGLA_VOWELS, label: 'স্বরবর্ণ (Vowels)' },
    { id: LayoutMode.BANGLA_MARKS, label: 'কার (Marks)' },
  ];

  return (
    <div className="flex flex-wrap gap-2 justify-center mb-6">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setMode(tab.id)}
          className={`
            px-4 py-2 rounded-full text-sm md:text-base font-medium transition-all duration-300
            ${currentMode === tab.id 
              ? 'bg-t-accent text-t-accentText shadow-lg' 
              : 'bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover'}
            ${tab.id !== LayoutMode.ENGLISH && tab.id !== LayoutMode.NUMBER_PAD && tab.id !== LayoutMode.EMOJI ? 'font-bangla' : 'font-sans'}
          `}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};
