
import React from 'react';
import { X, Shield, FileText } from 'lucide-react';

interface PolicyModalProps {
  type: 'privacy' | 'terms';
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ type, onClose }) => {
  const isPrivacy = type === 'privacy';
  const title = isPrivacy ? 'Privacy Policy' : 'Terms & Conditions';
  const Icon = isPrivacy ? Shield : FileText;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-t-panel border border-t-border rounded-xl w-full max-w-2xl shadow-2xl relative flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-t-border bg-t-key/50 rounded-t-xl">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-t-accent rounded-lg text-t-accentText">
              <Icon size={20} />
            </div>
            <h2 className="text-xl font-bold text-t-text">{title}</h2>
          </div>
          <button 
            onClick={onClose} 
            className="text-t-textMuted hover:text-t-text transition-colors p-1 hover:bg-t-key rounded-full"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 text-t-text custom-scrollbar">
          <div className="prose prose-invert prose-sm max-w-none">
            {isPrivacy ? (
              <>
                <p className="text-t-textMuted mb-4">Last Updated: 2026</p>
                
                <h3 className="text-lg font-bold text-t-accent mb-2">1. Information We Collect</h3>
                <p className="mb-4">
                  <strong>Input Data:</strong> When you use BanglaBoard 2026, the text you type is processed to provide transliteration, translation, and AI predictions. This processing happens via the Google Gemini API.
                  <br />
                  <strong>Local Storage:</strong> Your personal dictionary, theme preferences, and sound settings are stored locally on your device using Browser LocalStorage. We do not transmit this data to our own servers.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">2. How We Use Your Data</h3>
                <p className="mb-4">
                  We use the text input solely to:
                  <ul className="list-disc pl-5 mt-1 space-y-1">
                    <li>Convert phonetic typing to Bangla script.</li>
                    <li>Provide grammar corrections and smart completions.</li>
                    <li>Translate content as requested by you.</li>
                  </ul>
                  We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">3. AI & Third-Party Services</h3>
                <p className="mb-4">
                  This application utilizes <strong>Google Gemini AI</strong> for language processing. Data sent to the AI API is subject to Google's data processing terms. We recommend reviewing Google's Privacy Policy regarding API usage.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">4. Security</h3>
                <p className="mb-4">
                  We prioritize the security of your data. The application operates as a client-side Web App (PWA). Your custom dictionary remains on your device and is not synchronized to any cloud database by us.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">5. Contact</h3>
                <p>
                  For privacy concerns, please contact the developer at: <strong>Shariar Mazumdar</strong> (Developer Profile).
                </p>
              </>
            ) : (
              <>
                <p className="text-t-textMuted mb-4">Effective Date: January 1, 2026</p>

                <h3 className="text-lg font-bold text-t-accent mb-2">1. Acceptance of Terms</h3>
                <p className="mb-4">
                  By accessing and using BanglaBoard 2026 ("the Application"), you accept and agree to be bound by the terms and provision of this agreement.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">2. License to Use</h3>
                <p className="mb-4">
                  We grant you a personal, non-exclusive, non-transferable, limited license to use the Application for your personal, non-commercial use on devices supported by the Application (Android, iOS, Windows).
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">3. User Conduct</h3>
                <p className="mb-4">
                  You agree not to use the Application to generate content that is unlawful, harmful, threatening, abusive, harassing, defamatory, or otherwise objectionable. The AI features are intended for helpful text assistance.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">4. Disclaimer of Warranties</h3>
                <p className="mb-4">
                  The Application is provided "as is" and "as available" without any warranties of any kind, including but not limited to, implied warranties of merchantability or fitness for a particular purpose. We do not guarantee that the AI predictions or translations will always be 100% accurate.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">5. Intellectual Property</h3>
                <p className="mb-4">
                  The design, code, and branding of BanglaBoard 2026 are the intellectual property of <strong>Shariar Mazumdar</strong>. The underlying AI models are property of Google.
                </p>

                <h3 className="text-lg font-bold text-t-accent mb-2">6. Changes to Terms</h3>
                <p>
                  We reserve the right to modify these terms at any time. Your continued use of the Application after any such changes constitutes your acceptance of the new Terms and Conditions.
                </p>
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-t-border bg-t-key/50 rounded-b-xl flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-t-accent text-t-accentText font-bold rounded-lg hover:brightness-110 transition-all active:scale-95"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
