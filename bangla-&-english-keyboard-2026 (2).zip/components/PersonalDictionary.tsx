
import React, { useState } from 'react';
import { X, Book, Plus, Trash2, Save, AlertCircle } from 'lucide-react';

interface PersonalDictionaryProps {
  words: string[];
  onAddWord: (word: string) => void;
  onRemoveWord: (word: string) => void;
  onClearAll: () => void;
  onClose: () => void;
}

export const PersonalDictionary: React.FC<PersonalDictionaryProps> = ({ 
  words, 
  onAddWord, 
  onRemoveWord,
  onClearAll,
  onClose 
}) => {
  const [newWord, setNewWord] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newWord.trim()) {
      onAddWord(newWord.trim());
      setNewWord('');
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-t-panel border border-t-border rounded-xl p-6 w-full max-w-lg shadow-2xl relative flex flex-col max-h-[85vh]">
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-t-textMuted hover:text-t-text transition-colors"
        >
            <X size={24} />
        </button>
        
        <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-t-accent rounded-lg text-t-accentText">
                <Book size={20} />
            </div>
            <div>
                <h2 className="text-xl font-bold text-t-text">Personal Dictionary</h2>
                <p className="text-xs text-t-textMuted">Add custom words for better AI prediction</p>
            </div>
        </div>

        {/* Add Word Form */}
        <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
            <input 
                type="text" 
                value={newWord}
                onChange={(e) => setNewWord(e.target.value)}
                placeholder="Enter a new word or name..."
                className="flex-1 bg-t-key border border-t-border rounded-lg px-4 py-2 text-t-text outline-none focus:border-t-accent transition-colors"
                autoFocus
            />
            <button 
                type="submit"
                disabled={!newWord.trim()}
                className="bg-t-accent text-t-accentText px-4 py-2 rounded-lg font-medium hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
            >
                <Plus size={18} />
                Add
            </button>
        </form>
        
        {/* Word List */}
        <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar border-t border-t-border pt-4">
            {words.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 text-t-textMuted opacity-60 gap-2">
                    <Book size={40} />
                    <p>No custom words yet.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {words.map((word, idx) => (
                        <div key={`${word}-${idx}`} className="group flex items-center justify-between bg-t-key/50 border border-t-border rounded-lg px-3 py-2 hover:bg-t-key transition-colors">
                            <span className="text-t-text font-medium truncate mr-2">{word}</span>
                            <button 
                                onClick={() => onRemoveWord(word)}
                                className="text-t-textMuted hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all p-1 rounded hover:bg-red-500/10"
                                title="Remove word"
                            >
                                <Trash2 size={14} />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>

        {/* Footer Actions */}
        <div className="mt-4 pt-4 border-t border-t-border flex justify-between items-center">
            <button 
                onClick={() => {
                    if (window.confirm('Are you sure you want to delete all custom words?')) {
                        onClearAll();
                    }
                }}
                disabled={words.length === 0}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-red-400 hover:bg-red-500/10 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <Trash2 size={16} /> Clear All
            </button>
            <button 
                onClick={onClose}
                className="flex items-center gap-2 px-6 py-2.5 bg-t-key border border-t-border hover:bg-t-keyHover text-t-text font-medium rounded-lg transition-all"
            >
                <Save size={16} /> Done
            </button>
        </div>
      </div>
    </div>
  );
};
