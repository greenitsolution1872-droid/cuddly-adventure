
import React, { useState, useRef, useEffect } from 'react';
import { LayoutMode, AIStatus, OSType, ThemeType, ThemeDefinition, BeforeInstallPromptEvent } from './types';
import { VirtualKeyboard } from './components/VirtualKeyboard';
import { THEMES, SUPPORTED_LANGUAGES, DEFAULT_CUSTOM_THEME } from './constants';
import { ThemeCustomizer } from './components/ThemeCustomizer';
import { transliterateToBangla, translateText, fixGrammar, generateSmartCompletion } from './services/geminiService';
import { 
  Keyboard, 
  Languages, 
  CheckCheck, 
  Copy, 
  Trash2, 
  Loader2,
  Sparkles,
  Smartphone,
  Monitor,
  Apple,
  Globe,
  Palette,
  Edit3,
  Volume2,
  VolumeX,
  ChevronDown,
  Download,
  Share,
  X,
  Menu
} from 'lucide-react';

const App: React.FC = () => {
  const [text, setText] = useState('');
  const [mode, setMode] = useState<LayoutMode>(LayoutMode.ENGLISH);
  const [aiStatus, setAiStatus] = useState<AIStatus>(AIStatus.IDLE);
  const [capsLock, setCapsLock] = useState(false);
  const [os, setOs] = useState<OSType>('Unknown');
  const [currentTheme, setCurrentTheme] = useState<ThemeType>(ThemeType.NEON);
  const [targetLang, setTargetLang] = useState('English');
  const [customTheme, setCustomTheme] = useState<ThemeDefinition>(() => {
    const saved = localStorage.getItem('customTheme');
    return saved ? JSON.parse(saved) : DEFAULT_CUSTOM_THEME;
  });
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(() => {
    const saved = localStorage.getItem('soundEnabled');
    return saved !== null ? JSON.parse(saved) : true;
  });
  
  // PWA Install State
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showInstallModal, setShowInstallModal] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Apply Theme
  useEffect(() => {
    let themeVars: ThemeDefinition;
    if (currentTheme === ThemeType.CUSTOM) {
      themeVars = customTheme;
    } else {
      themeVars = THEMES[currentTheme];
    }
    
    Object.entries(themeVars).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value as string);
    });
  }, [currentTheme, customTheme]);

  // Save Custom Theme
  useEffect(() => {
    localStorage.setItem('customTheme', JSON.stringify(customTheme));
  }, [customTheme]);

  // Save Sound Preference
  useEffect(() => {
    localStorage.setItem('soundEnabled', JSON.stringify(soundEnabled));
  }, [soundEnabled]);

  // Detect OS
  useEffect(() => {
    const userAgent = window.navigator.userAgent;
    if (/android/i.test(userAgent)) {
      setOs('Android');
    } else if (/iPad|iPhone|iPod/.test(userAgent)) {
      setOs('iOS');
    } else if (/windows/i.test(userAgent)) {
      setOs('Windows');
    } else if (/macintosh|mac os x/i.test(userAgent)) {
      setOs('MacOS');
    } else if (/linux/i.test(userAgent)) {
      setOs('Linux');
    }
  }, []);

  // PWA Install Prompt Listener
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  // Focus textarea on load, but be careful on mobile to not auto-open native keyboard
  useEffect(() => {
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS' || os === 'Linux')) {
      textareaRef.current.focus();
    }
  }, [os]);

  const handleKeyPress = (char: string) => {
    setText(prev => prev + char);
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }
  };

  const handleBackspace = () => {
    setText(prev => prev.slice(0, -1));
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }
  };

  const handleSpace = () => {
    setText(prev => prev + ' ');
    if (textareaRef.current && (os === 'Windows' || os === 'MacOS')) {
      textareaRef.current.focus();
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(text);
  };

  const clearText = () => {
    if (window.confirm('Clear all text?')) {
      setText('');
    }
  };

  const updateCustomTheme = (key: keyof ThemeDefinition, value: string) => {
    setCustomTheme(prev => ({ ...prev, [key]: value }));
  };

  const resetCustomTheme = () => {
    if (window.confirm('Reset custom theme to defaults?')) {
        setCustomTheme(DEFAULT_CUSTOM_THEME);
    }
  };

  // Install Action
  const handleInstallClick = async () => {
    if (installPrompt) {
      installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      if (outcome === 'accepted') {
        setInstallPrompt(null);
        setShowInstallModal(false);
      }
    } else {
      setShowInstallModal(true);
    }
  };

  // AI Actions
  const handleTransliterate = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await transliterateToBangla(text);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleTranslate = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await translateText(text, targetLang);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleFixGrammar = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    try {
      const result = await fixGrammar(text);
      setText(result);
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const handleAiMagic = async () => {
    if (!text.trim()) return;
    setAiStatus(AIStatus.LOADING);
    
    // Determine context language based on current keyboard mode
    let contextLang = targetLang;
    if (mode === LayoutMode.BANGLA_CONSONANTS || 
        mode === LayoutMode.BANGLA_VOWELS || 
        mode === LayoutMode.BANGLA_MARKS) {
      contextLang = "Bangla";
    }

    try {
      const result = await generateSmartCompletion(text, contextLang);
      if (result) {
          setText(prev => prev + " " + result);
      }
      setAiStatus(AIStatus.SUCCESS);
    } catch (e) {
      setAiStatus(AIStatus.ERROR);
    } finally {
      setTimeout(() => setAiStatus(AIStatus.IDLE), 2000);
    }
  };

  const getOSIcon = () => {
    switch(os) {
      case 'Android': return <Smartphone size={16} className="text-t-accent" />;
      case 'iOS': return <Apple size={16} className="text-t-textMuted" />;
      case 'MacOS': return <Apple size={16} className="text-t-textMuted" />;
      case 'Windows': return <Monitor size={16} className="text-t-accent" />;
      default: return <Monitor size={16} className="text-t-textMuted" />;
    }
  };

  const selectedLanguage = SUPPORTED_LANGUAGES.find(l => l.name === targetLang) || SUPPORTED_LANGUAGES[0];

  const layoutOptions = [
    { value: LayoutMode.ENGLISH, label: 'English (ABC)' },
    { value: LayoutMode.NUMBER_PAD, label: 'Numbers (123)' },
    { value: LayoutMode.EMOJI, label: 'Emoji (😊)' },
    { value: LayoutMode.BANGLA_CONSONANTS, label: 'Bangla: Consonants' },
    { value: LayoutMode.BANGLA_VOWELS, label: 'Bangla: Vowels' },
    { value: LayoutMode.BANGLA_MARKS, label: 'Bangla: Marks' },
  ];

  return (
    <div className="min-h-screen bg-t-bg text-t-text flex flex-col font-sans selection:bg-t-accent selection:text-t-accentText pb-10 transition-colors duration-300">
      {/* Background Ambience - Only for Neon/Dark/Custom themes roughly */}
      {(currentTheme === ThemeType.NEON || currentTheme === ThemeType.DARK || currentTheme === ThemeType.CUSTOM) && (
        <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-t-accent opacity-10 blur-[120px] rounded-full animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-t-accent opacity-10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        </div>
      )}

      {/* Header */}
      <header className="w-full p-3 md:p-6 flex flex-col md:flex-row items-center justify-between border-b border-t-border glass-panel sticky top-0 z-50 transition-colors duration-300 gap-3">
        <div className="flex items-center justify-between w-full md:w-auto">
          <div className="flex items-center gap-3">
            <div className="bg-t-accent p-2 rounded-lg">
              <Keyboard className="text-t-accentText" size={24} />
            </div>
            <div>
              <h1 className="text-lg md:text-2xl font-bold tracking-tight text-t-text leading-tight">
                BanglaBoard <span className="text-t-accent">2026</span>
              </h1>
              <div className="flex items-center gap-2">
                <span className="text-[10px] md:text-xs text-t-textMuted font-medium hidden sm:inline-block">AI-Powered Input</span>
                {os !== 'Unknown' && (
                  <div className="flex items-center gap-1 bg-white/5 px-2 py-0.5 rounded-full border border-t-border">
                    {getOSIcon()}
                    <span className="text-[10px] text-t-textMuted uppercase font-semibold">{os}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Mobile Status Indicator */}
          <div className={`md:hidden px-3 py-1 rounded-full text-[10px] font-bold border ${aiStatus === AIStatus.LOADING ? 'border-neon-pink text-neon-pink animate-pulse' : 'border-t-border text-t-textMuted'}`}>
             {aiStatus === AIStatus.LOADING ? 'BUSY' : 'READY'}
          </div>
        </div>
        
        <div className="flex items-center gap-2 md:gap-3 w-full md:w-auto justify-end">
           
           {/* Layout Selector Dropdown */}
           <div className="relative flex items-center bg-t-key border border-t-border rounded-lg px-2 py-1.5 gap-2 group hover:border-t-accent transition-colors">
              <Keyboard size={16} className="text-t-textMuted group-hover:text-t-accent transition-colors flex-shrink-0"/>
              <select 
                value={mode} 
                onChange={(e) => setMode(e.target.value as LayoutMode)}
                className="bg-transparent outline-none text-xs md:text-sm font-medium text-t-text appearance-none cursor-pointer w-[110px] sm:w-[130px] md:w-auto"
              >
                {layoutOptions.map(opt => (
                  <option key={opt.value} value={opt.value} className="bg-t-bg text-t-text">
                    {opt.label}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="text-t-textMuted pointer-events-none absolute right-2 bg-t-key pl-1" />
           </div>

           <div className="h-6 w-px bg-t-border mx-1"></div>

           {/* Sound Toggle */}
           <button 
             onClick={() => setSoundEnabled(!soundEnabled)}
             className="p-1.5 md:p-2 rounded-full border border-t-border bg-t-key text-t-textMuted hover:text-t-accent hover:bg-t-keyHover transition-all flex-shrink-0"
             title={soundEnabled ? "Mute Sound" : "Enable Sound"}
           >
             {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
           </button>

           {/* Theme Selector */}
           <div className="flex items-center gap-1 bg-t-key rounded-full p-1 border border-t-border flex-shrink-0">
             {[ThemeType.NEON, ThemeType.LIGHT, ThemeType.DARK, ThemeType.FOREST].map(t => (
               <button
                 key={t}
                 onClick={() => setCurrentTheme(t)}
                 className={`w-5 h-5 md:w-6 md:h-6 rounded-full border border-t-border transition-transform ${currentTheme === t ? 'scale-110 ring-2 ring-t-accent' : 'hover:scale-105 opacity-60 hover:opacity-100'}`}
                 style={{ backgroundColor: THEMES[t]['--bg-app'] }}
                 title={t}
                 aria-label={`Select ${t} theme`}
               />
             ))}
             
             {/* Custom Theme Trigger */}
             <div className="relative flex items-center">
                <button
                    onClick={() => {
                        setCurrentTheme(ThemeType.CUSTOM);
                        if (currentTheme === ThemeType.CUSTOM) setShowCustomizer(true);
                    }}
                    className={`w-5 h-5 md:w-6 md:h-6 rounded-full border border-t-border flex items-center justify-center transition-all overflow-hidden ${currentTheme === ThemeType.CUSTOM ? 'scale-110 ring-2 ring-t-accent' : 'hover:scale-105 opacity-60 hover:opacity-100'}`}
                    style={{ background: 'conic-gradient(from 0deg, red, yellow, lime, aqua, blue, magenta, red)' }}
                    title="Custom Theme"
                >
                    {currentTheme === ThemeType.CUSTOM && (
                         <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[1px]">
                             <Palette size={10} className="text-white" />
                         </div>
                    )}
                </button>
             </div>
           </div>
           
           {currentTheme === ThemeType.CUSTOM && (
               <button 
                  onClick={() => setShowCustomizer(true)}
                  className="p-1.5 rounded-full bg-t-key border border-t-border hover:border-t-accent text-t-textMuted hover:text-t-accent transition-colors flex-shrink-0"
                  title="Edit Custom Theme"
               >
                   <Edit3 size={14} />
               </button>
           )}

           {/* Download / Install App */}
           <button
              onClick={handleInstallClick}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-t-accent to-blue-500 text-t-accentText font-bold shadow-lg hover:brightness-110 transition-all active:scale-95 ml-2"
           >
              <Download size={16} />
              <span className="text-xs">App</span>
           </button>

           <div className={`hidden md:block px-3 py-1 rounded-full text-[10px] md:text-xs font-bold border ${aiStatus === AIStatus.LOADING ? 'border-neon-pink text-neon-pink animate-pulse' : 'border-t-border text-t-textMuted'}`}>
             {aiStatus === AIStatus.LOADING ? 'PROCESSING' : 'ONLINE'}
           </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-6xl mx-auto p-2 md:p-8 flex flex-col gap-4 md:gap-6">
        
        {/* Editor Section */}
        <section className="relative group mt-2 md:mt-0">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-t-accent to-t-textMuted rounded-2xl opacity-20 group-hover:opacity-40 transition duration-500 blur-md"></div>
          <div className="relative glass-panel rounded-2xl p-4 md:p-6 h-[200px] md:h-[300px] flex flex-col">
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={`Start typing... (Try the ✨ Magic key for AI completion)`}
              className="flex-1 bg-transparent border-none outline-none resize-none text-lg md:text-2xl font-bangla leading-relaxed placeholder-t-textMuted w-full text-t-text"
              spellCheck="false"
            />
            
            {/* Toolbar inside textarea */}
            <div className="flex justify-between items-center mt-4 border-t border-t-border pt-4">
              <div className="flex gap-2 text-xs text-t-textMuted">
                <span>{text.length} chars</span>
                <span>{text.split(/\s+/).filter(w => w.length > 0).length} words</span>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={copyToClipboard}
                  className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-t-accent transition-colors"
                  title="Copy Text"
                >
                  <Copy size={18} />
                </button>
                <button 
                  onClick={clearText}
                  className="p-2 hover:bg-t-keyHover rounded-lg text-t-textMuted hover:text-red-500 transition-colors"
                  title="Clear Text"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* AI Action Bar */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-2 md:gap-3">
          <button
            onClick={handleTransliterate}
            disabled={aiStatus === AIStatus.LOADING}
            className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-t-accent hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
            {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-t-accent" size={20} /> : <Sparkles className="text-t-accent group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Phonetic to Bangla</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">ami -{'>'} আমি</span>
          </button>

          <button
            onClick={handleFixGrammar}
            disabled={aiStatus === AIStatus.LOADING}
            className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-t-accent hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
             {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-t-accent" size={20} /> : <CheckCheck className="text-t-accent group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Fix Grammar</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">Auto-correct</span>
          </button>

          {/* Target Language Selector */}
          <div className="relative flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-blue-400 hover:bg-t-keyHover transition-all group text-t-text">
             <select 
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
             >
                {SUPPORTED_LANGUAGES.map(lang => (
                  <option key={lang.code} value={lang.name}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
             </select>
             <Globe className="text-blue-400 group-hover:scale-110 transition-transform" size={20} />
             <span className="text-xs md:text-sm font-medium truncate max-w-full px-2">{selectedLanguage.name}</span>
             <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">{selectedLanguage.flag} Target Lang</span>
          </div>

          <button
             onClick={handleTranslate}
             disabled={aiStatus === AIStatus.LOADING}
             className="flex flex-col items-center justify-center gap-1 md:gap-2 p-3 md:p-4 rounded-xl bg-t-key border border-t-border hover:border-green-400 hover:bg-t-keyHover transition-all group disabled:opacity-50 disabled:cursor-not-allowed text-t-text"
          >
             {aiStatus === AIStatus.LOADING ? <Loader2 className="animate-spin text-green-400" size={20} /> : <Languages className="text-green-400 group-hover:scale-110 transition-transform" size={20} />}
            <span className="text-xs md:text-sm font-medium">Translate</span>
            <span className="text-[10px] md:text-xs text-t-textMuted hidden sm:inline">To {targetLang}</span>
          </button>
        </section>

        {/* Keyboard Section */}
        <section className="flex-1 pb-20">
          
          <div className="glass-panel p-1 md:p-6 rounded-2xl border-t border-t-border transition-colors duration-300">
            <VirtualKeyboard 
              mode={mode} 
              setMode={setMode}
              onKeyPress={handleKeyPress}
              onBackspace={handleBackspace}
              onSpace={handleSpace}
              capsLock={capsLock}
              toggleCapsLock={() => setCapsLock(!capsLock)}
              soundEnabled={soundEnabled}
              onAiMagic={handleAiMagic}
            />
          </div>
          
          <div className="text-center mt-6 text-t-textMuted text-xs">
             <p>Use the <span className="inline-block px-1.5 py-0.5 rounded bg-gradient-to-r from-neon-blue to-neon-purple text-white text-[10px] font-bold">✨</span> key to auto-complete thoughts or answer questions in {targetLang}.</p>
          </div>
        </section>

        {/* Custom Theme Editor Modal */}
        {showCustomizer && (
            <ThemeCustomizer 
                theme={customTheme}
                onUpdate={updateCustomTheme}
                onReset={resetCustomTheme}
                onClose={() => setShowCustomizer(false)}
            />
        )}

        {/* Install / Download Modal */}
        {showInstallModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
             <div className="bg-t-panel border border-t-border rounded-xl p-6 w-full max-w-sm shadow-2xl relative flex flex-col">
                <button 
                  onClick={() => setShowInstallModal(false)} 
                  className="absolute top-4 right-4 text-t-textMuted hover:text-t-text transition-colors"
                >
                  <X size={20} />
                </button>

                <div className="flex flex-col items-center text-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-t-accent to-purple-600 rounded-2xl shadow-lg flex items-center justify-center">
                    <Keyboard className="text-white w-8 h-8" />
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold text-t-text">BanglaBoard 2026</h3>
                    <p className="text-t-textMuted text-sm">Next-Gen AI Keyboard</p>
                  </div>

                  <div className="w-full h-px bg-t-border my-2"></div>

                  <div className="flex flex-col gap-3 w-full">
                    {/* Simulated Store Badges */}
                    <div className="grid grid-cols-1 gap-3">
                       {/* Android / Chrome */}
                       <button
                          onClick={() => {
                            if(installPrompt) installPrompt.prompt();
                            else if (os === 'Android') alert('Tap the menu (⋮) and select "Install App" or "Add to Home Screen".');
                          }}
                          className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'Android' ? 'ring-2 ring-t-accent' : ''}`}
                       >
                         <Smartphone className="text-green-500" />
                         <div className="text-left">
                           <div className="text-[10px] uppercase text-t-textMuted font-bold">Get it on</div>
                           <div className="text-sm font-bold text-t-text">Google Play</div>
                         </div>
                       </button>

                       {/* iOS */}
                       <button
                          onClick={() => {
                             if(os === 'iOS') alert('Tap the Share button below, then scroll down and select "Add to Home Screen"');
                             else alert('On iOS Safari: Tap Share > Add to Home Screen');
                          }}
                          className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'iOS' ? 'ring-2 ring-t-accent' : ''}`}
                       >
                         <Apple className="text-white" />
                         <div className="text-left">
                           <div className="text-[10px] uppercase text-t-textMuted font-bold">Download on the</div>
                           <div className="text-sm font-bold text-t-text">App Store</div>
                         </div>
                       </button>

                       {/* Windows */}
                       <button
                          onClick={() => {
                             if(installPrompt) installPrompt.prompt();
                             else alert('Click the install icon in your browser address bar (usually top right).');
                          }}
                          className={`flex items-center gap-3 p-3 rounded-lg border border-t-border bg-t-key hover:bg-t-keyHover transition-all ${os === 'Windows' ? 'ring-2 ring-t-accent' : ''}`}
                       >
                         <Monitor className="text-blue-400" />
                         <div className="text-left">
                           <div className="text-[10px] uppercase text-t-textMuted font-bold">Get it from</div>
                           <div className="text-sm font-bold text-t-text">Microsoft Store</div>
                         </div>
                       </button>
                    </div>
                  </div>
                  
                  {os === 'iOS' && (
                     <div className="mt-2 text-xs text-t-textMuted bg-t-key p-3 rounded-lg animate-pulse">
                        <div className="flex items-center justify-center gap-2 mb-1 font-bold text-t-text">
                           <Share size={12} /> Tap Share
                        </div>
                        Then select "Add to Home Screen"
                     </div>
                  )}
                  
                  {installPrompt && (
                    <p className="text-xs text-green-400 mt-2 font-medium">
                      One-click install available! Tap your store above.
                    </p>
                  )}
                </div>
             </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
