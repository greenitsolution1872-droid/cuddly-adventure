
import React from 'react';
import { ThemeDefinition } from '../types';
import { RefreshCcw, X, Palette } from 'lucide-react';

interface ThemeCustomizerProps {
  theme: ThemeDefinition;
  onUpdate: (key: keyof ThemeDefinition, value: string) => void;
  onReset: () => void;
  onClose: () => void;
}

export const ThemeCustomizer: React.FC<ThemeCustomizerProps> = ({ theme, onUpdate, onReset, onClose }) => {
  const labels: Record<keyof ThemeDefinition, string> = {
    '--bg-app': 'App Background',
    '--bg-panel': 'Panel Background',
    '--bg-key': 'Key Background',
    '--bg-key-hover': 'Key Hover',
    '--border-key': 'Key Border',
    '--text-primary': 'Primary Text',
    '--text-secondary': 'Secondary Text',
    '--accent-color': 'Accent Color',
    '--text-accent': 'Accent Text',
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-t-panel border border-t-border rounded-xl p-6 w-full max-w-lg shadow-2xl relative flex flex-col max-h-[90vh]">
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-t-textMuted hover:text-t-text transition-colors"
        >
            <X size={24} />
        </button>
        
        <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-t-accent rounded-lg text-t-accentText">
                <Palette size={20} />
            </div>
            <h2 className="text-xl font-bold text-t-text">Custom Theme</h2>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 overflow-y-auto pr-2 custom-scrollbar flex-1 pb-4">
          {(Object.keys(theme) as Array<keyof ThemeDefinition>).map((key) => {
             const isHex = theme[key].startsWith('#') && (theme[key].length === 7 || theme[key].length === 4);
             const fallbackColor = '#000000';
             
             return (
                <div key={key} className="flex flex-col gap-1 p-3 rounded-lg bg-t-key/50 border border-t-border">
                  <span className="text-xs font-medium text-t-textMuted uppercase tracking-wider">{labels[key]}</span>
                  <div className="flex items-center gap-2 mt-1">
                     <div className="relative w-10 h-10 rounded-lg overflow-hidden border border-t-border shadow-sm flex-shrink-0">
                         <input 
                            type="color" 
                            value={isHex ? theme[key] : fallbackColor} 
                            onChange={(e) => onUpdate(key, e.target.value)}
                            className="absolute -top-1/2 -left-1/2 w-[200%] h-[200%] p-0 cursor-pointer border-none"
                         />
                     </div>
                     <input
                        type="text"
                        value={theme[key]}
                        onChange={(e) => onUpdate(key, e.target.value)}
                        className="w-full bg-transparent text-sm border-b border-t-border focus:border-t-accent outline-none font-mono text-t-text py-1"
                        spellCheck={false}
                    />
                  </div>
                </div>
            );
          })}
        </div>

        <div className="mt-4 pt-4 border-t border-t-border flex justify-between items-center">
            <button 
                onClick={onReset}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
            >
                <RefreshCcw size={16} /> Reset Default
            </button>
            <button 
                onClick={onClose}
                className="px-6 py-2.5 bg-t-accent text-t-accentText font-bold rounded-lg shadow-lg hover:brightness-110 transition-all active:scale-95"
            >
                Save & Close
            </button>
        </div>
      </div>
    </div>
  );
};
