
import React, { useRef } from 'react';
import { LayoutMode, KeyData } from '../types';
import { ENGLISH_LAYOUT, NUMBER_PAD_LAYOUT, EMOJI_LAYOUT, BANGLA_VOWELS, BANGLA_CONSONANTS, BANGLA_MARKS } from '../constants';
import { ArrowBigUp, Delete, Space, Smile, Sparkles } from 'lucide-react';

interface VirtualKeyboardProps {
  mode: LayoutMode;
  setMode: (mode: LayoutMode) => void;
  onKeyPress: (char: string) => void;
  onBackspace: () => void;
  onSpace: () => void;
  capsLock: boolean;
  toggleCapsLock: () => void;
  soundEnabled: boolean;
  onAiMagic: () => void;
}

export const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({
  mode,
  setMode,
  onKeyPress,
  onBackspace,
  onSpace,
  capsLock,
  toggleCapsLock,
  soundEnabled,
  onAiMagic
}) => {
  const audioContextRef = useRef<AudioContext | null>(null);

  const triggerHaptic = () => {
    if (navigator.vibrate) {
      navigator.vibrate(10);
    }
  };

  const playClickSound = () => {
    if (!soundEnabled) return;

    try {
        if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        const ctx = audioContextRef.current;
        
        if (ctx.state === 'suspended') {
            ctx.resume();
        }

        // Create a short, pleasant click
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.connect(gain);
        gain.connect(ctx.destination);

        // Soft sine wave click for a modern mobile feel
        osc.type = 'sine';
        
        // Pitch drop simulates a tap
        osc.frequency.setValueAtTime(500, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.05);

        // Volume envelope for short duration
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.05);
    } catch (e) {
        // Fallback or ignore if audio context fails
        console.warn("Audio playback failed", e);
    }
  };

  const handleKeyClick = (char: string) => {
    triggerHaptic();
    playClickSound();
    onKeyPress(char);
  };

  const handleSpecialKey = (action: () => void) => {
    triggerHaptic();
    playClickSound();
    action();
  };
  
  const renderKey = (key: KeyData, index: number) => {
    const displayChar = (mode === LayoutMode.ENGLISH && capsLock && key.shift) 
      ? key.shift 
      : (key.display || key.char);
      
    const valueChar = (mode === LayoutMode.ENGLISH && capsLock && key.shift)
      ? key.shift
      : key.char;

    return (
      <button
        key={`${key.char}-${index}`}
        onClick={() => handleKeyClick(valueChar)}
        className={`
          relative group flex items-center justify-center
          m-0.5 md:m-1 p-0 md:p-3 rounded-lg md:rounded-xl
          bg-t-key border border-t-border
          hover:border-t-accent hover:bg-t-keyHover hover:shadow-lg
          active:scale-95 transition-all duration-150
          flex-grow
          min-w-[32px] sm:min-w-[40px] md:min-w-[50px] lg:min-w-[60px] 
          h-[45px] sm:h-[50px] md:h-[60px]
          text-lg md:text-xl font-medium text-t-text
          ${mode !== LayoutMode.ENGLISH && mode !== LayoutMode.NUMBER_PAD && mode !== LayoutMode.EMOJI ? 'font-bangla' : 'font-sans'}
          cursor-pointer touch-manipulation
        `}
      >
        {displayChar}
      </button>
    );
  };

  const renderEnglish = () => (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto gap-1">
      {ENGLISH_LAYOUT.map((row, rowIndex) => (
        <div key={rowIndex} className="flex justify-center w-full gap-0.5 md:gap-1">
          {row.map((key, kIndex) => renderKey(key, kIndex))}
        </div>
      ))}
      <div className="flex justify-center w-full mt-2 gap-1 md:gap-2 px-1 md:px-4">
        <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.NUMBER_PAD))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[45px] md:min-w-[50px] touch-manipulation font-bold text-sm transition-colors"
        >
          123
        </button>
         <button
          onClick={() => handleSpecialKey(toggleCapsLock)}
          className={`flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border h-[45px] sm:h-[50px] md:h-[60px] min-w-[45px] md:min-w-[50px] transition-all touch-manipulation
            ${capsLock ? 'bg-t-accent text-t-accentText font-bold shadow-md' : 'bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover'}`}
        >
          <ArrowBigUp size={20} className={`md:w-6 md:h-6 ${capsLock ? 'fill-current' : ''}`} />
        </button>
        <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.EMOJI))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[45px] md:min-w-[50px] touch-manipulation transition-colors"
        >
          <Smile size={20} className="md:w-6 md:h-6" />
        </button>
        
        {/* AI Key */}
        <button
          onClick={() => handleSpecialKey(onAiMagic)}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border-none bg-gradient-to-br from-neon-blue to-neon-purple text-white shadow-lg hover:shadow-neon-blue/50 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] min-w-[45px] md:min-w-[50px] touch-manipulation"
        >
          <Sparkles size={20} className="md:w-6 md:h-6 fill-white/20" />
        </button>

        <button
          onClick={() => handleSpecialKey(onSpace)}
          className="flex-1 flex items-center justify-center bg-t-key border border-t-border rounded-lg md:rounded-xl hover:border-t-accent active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] touch-manipulation text-t-text"
        >
          <Space size={20} className="text-t-textMuted" />
        </button>
        <button
          onClick={() => handleSpecialKey(onBackspace)}
          className="flex items-center justify-center px-2 md:px-4 bg-t-key border border-t-border rounded-lg md:rounded-xl hover:bg-red-500/20 hover:border-red-500 hover:text-red-500 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] min-w-[45px] md:min-w-[60px] touch-manipulation text-t-text"
        >
          <Delete size={20} className="md:w-6 md:h-6" />
        </button>
      </div>
    </div>
  );

  const renderNumberPad = () => (
    <div className="flex flex-col items-center w-full max-w-lg mx-auto gap-1">
      {NUMBER_PAD_LAYOUT.map((row, rowIndex) => (
        <div key={rowIndex} className="flex justify-center w-full gap-0.5 md:gap-1">
          {row.map((key, kIndex) => renderKey(key, kIndex))}
        </div>
      ))}
      <div className="flex justify-center w-full mt-2 gap-1 md:gap-2 px-1 md:px-4">
        <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.ENGLISH))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation font-bold text-sm transition-colors"
        >
          ABC
        </button>
        <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.EMOJI))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation transition-colors"
        >
          <Smile size={20} className="md:w-6 md:h-6" />
        </button>
        
        {/* AI Key */}
        <button
          onClick={() => handleSpecialKey(onAiMagic)}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border-none bg-gradient-to-br from-neon-blue to-neon-purple text-white shadow-lg hover:shadow-neon-blue/50 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation"
        >
          <Sparkles size={20} className="md:w-6 md:h-6 fill-white/20" />
        </button>

        <button
          onClick={() => handleSpecialKey(onSpace)}
          className="flex-1 flex items-center justify-center bg-t-key border border-t-border rounded-lg md:rounded-xl hover:border-t-accent active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] text-sm md:text-base touch-manipulation text-t-text"
        >
          SPACE
        </button>
        <button
          onClick={() => handleSpecialKey(onBackspace)}
          className="flex items-center justify-center px-4 md:px-6 bg-t-key border border-t-border rounded-lg md:rounded-xl hover:bg-red-500/20 hover:border-red-500 hover:text-red-500 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] touch-manipulation text-t-text"
        >
          <Delete size={20} className="md:w-6 md:h-6" />
        </button>
      </div>
    </div>
  );

  const renderEmojiGrid = () => (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto gap-1">
       {EMOJI_LAYOUT.map((row, rowIndex) => (
        <div key={rowIndex} className="flex justify-center w-full gap-0.5 md:gap-1">
          {row.map((key, kIndex) => renderKey(key, kIndex))}
        </div>
      ))}
      <div className="flex justify-center w-full mt-2 gap-1 md:gap-2 px-1 md:px-4">
        <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.ENGLISH))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation font-bold text-sm transition-colors"
        >
          ABC
        </button>
         <button
          onClick={() => handleSpecialKey(() => setMode(LayoutMode.NUMBER_PAD))}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation font-bold text-sm transition-colors"
        >
          123
        </button>
        
        {/* AI Key - Emoji layout doesn't usually type, but good to have access */}
        <button
          onClick={() => handleSpecialKey(onAiMagic)}
          className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border-none bg-gradient-to-br from-neon-blue to-neon-purple text-white shadow-lg hover:shadow-neon-blue/50 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation"
        >
          <Sparkles size={20} className="md:w-6 md:h-6 fill-white/20" />
        </button>

        <button
          onClick={() => handleSpecialKey(onSpace)}
          className="flex-1 flex items-center justify-center bg-t-key border border-t-border rounded-lg md:rounded-xl hover:border-t-accent active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] text-sm md:text-base touch-manipulation text-t-text"
        >
          SPACE
        </button>
        <button
          onClick={() => handleSpecialKey(onBackspace)}
          className="flex items-center justify-center px-4 md:px-6 bg-t-key border border-t-border rounded-lg md:rounded-xl hover:bg-red-500/20 hover:border-red-500 hover:text-red-500 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] touch-manipulation text-t-text"
        >
          <Delete size={20} className="md:w-6 md:h-6" />
        </button>
      </div>
    </div>
  )

  const renderBanglaGrid = (keys: KeyData[]) => (
    <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-1 md:gap-2 p-1 md:p-2 w-full max-w-5xl mx-auto">
      {keys.map((key, index) => renderKey(key, index))}
    </div>
  );

  const renderBanglaConsonants = () => (
    <div className="flex flex-col gap-1 md:gap-2 w-full max-w-5xl mx-auto items-center">
      {BANGLA_CONSONANTS.map((row, rIdx) => (
        <div key={rIdx} className="flex flex-wrap justify-center w-full gap-0.5 md:gap-1">
          {row.map((key, cIdx) => renderKey(key, cIdx))}
        </div>
      ))}
    </div>
  );

  return (
    <div className="w-full select-none">
      {mode === LayoutMode.ENGLISH && renderEnglish()}
      {mode === LayoutMode.NUMBER_PAD && renderNumberPad()}
      {mode === LayoutMode.EMOJI && renderEmojiGrid()}
      {mode === LayoutMode.BANGLA_VOWELS && renderBanglaGrid(BANGLA_VOWELS)}
      {mode === LayoutMode.BANGLA_MARKS && renderBanglaGrid(BANGLA_MARKS)}
      {mode === LayoutMode.BANGLA_CONSONANTS && renderBanglaConsonants()}
      
      {(mode !== LayoutMode.ENGLISH && mode !== LayoutMode.NUMBER_PAD && mode !== LayoutMode.EMOJI) && (
        <div className="flex justify-center w-full mt-2 md:mt-4 gap-1 md:gap-2 px-1 md:px-4 max-w-2xl mx-auto">
          <button
            onClick={() => handleSpecialKey(() => setMode(LayoutMode.NUMBER_PAD))}
            className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation font-bold text-sm transition-colors"
          >
            123
          </button>
           <button
            onClick={() => handleSpecialKey(() => setMode(LayoutMode.EMOJI))}
            className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border border-t-border bg-t-key text-t-textMuted hover:text-t-text hover:bg-t-keyHover h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation transition-colors"
          >
            <Smile size={20} className="md:w-6 md:h-6" />
          </button>
          
          {/* AI Key */}
          <button
            onClick={() => handleSpecialKey(onAiMagic)}
            className="flex items-center justify-center px-2 md:px-4 rounded-lg md:rounded-xl border-none bg-gradient-to-br from-neon-blue to-neon-purple text-white shadow-lg hover:shadow-neon-blue/50 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] min-w-[50px] md:min-w-[60px] touch-manipulation"
          >
            <Sparkles size={20} className="md:w-6 md:h-6 fill-white/20" />
          </button>

          <button
            onClick={() => handleSpecialKey(onSpace)}
            className="flex-1 flex items-center justify-center bg-t-key border border-t-border rounded-lg md:rounded-xl hover:border-t-accent active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] text-sm md:text-base touch-manipulation text-t-text"
          >
            SPACE
          </button>
          <button
            onClick={() => handleSpecialKey(onBackspace)}
            className="flex items-center justify-center px-4 md:px-6 bg-t-key border border-t-border rounded-lg md:rounded-xl hover:bg-red-500/20 hover:border-red-500 hover:text-red-500 active:scale-95 transition-all h-[45px] sm:h-[50px] md:h-[60px] touch-manipulation text-t-text"
          >
            <Delete size={20} className="md:w-6 md:h-6" />
          </button>
        </div>
      )}
    </div>
  );
};
